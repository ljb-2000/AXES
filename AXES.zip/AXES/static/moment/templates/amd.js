/*global define:false*/

import moment from "./moment";

define([], function () {
    return moment;
});
